const portfolioRoutes = require("./portfolio");

const constructorMethod = app => {
  app.use("/", portfolioRoutes);

  app.use("*", (req, res) => {
    res.render("error",{err: 404, flag: 1, error: "you are not logged in ",title:"page not found"});
  });
};

module.exports = constructorMethod;
